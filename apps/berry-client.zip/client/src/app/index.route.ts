import { createRouter, createWebHistory } from 'vue-router';
import { dashboardRoutes } from '../modules/dashboard/dasboard.route';
import AppLayout from '../components/layouts/AppLayout.vue';
import { AuthRoutes, ProfileRoutes, UsersRoutes } from '../router';

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      component: AppLayout,
      children: [
        ...AuthRoutes,
        ...dashboardRoutes,
        ...ProfileRoutes,
        ...UsersRoutes,
      ],
    },
    {
      path: '/:catchAll(.*)',
      component: () => import('../views/NotFoundView.vue'),
    },
  ],
});

export default router;
