<script setup lang="ts">
import { useAuth0 } from '@auth0/auth0-vue';

const { loginWithRedirect, logout, isAuthenticated, user } = useAuth0();
const logoutUrl: string =
  import.meta.env.VITE_AUTH0_CALLBACK_URL || 'http://localhost:4200';
</script>

<template>
  <div v-if="isAuthenticated">
    <p>Welcome, {{ user?.name }}</p>
    <button @click="logout({ returnTo: logoutUrl })" class="bg-green-400">
      Logout
    </button>
  </div>
  <button
    v-else
    @click="loginWithRedirect()"
    class="bg-green-400 w-72 h-12 rounded-lg text-2xl"
  >
    Login
  </button>
</template>
