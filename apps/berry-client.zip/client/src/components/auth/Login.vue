<template>
  <div>
    <h1>Login</h1>
    <input v-model="username" placeholder="Enter your name" />
    <button @click="login">Login</button>
  </div>
</template>

<script setup lang="ts">
import { useAuthStore } from '../../stores/auth.store';
import { useRouter } from 'vue-router';

const authStore = useAuthStore();
const router = useRouter();
authStore.handleRedirectCallback().then(() => {
  alert('Redirected to home page after login');
  router.push('/');
});
</script>
