<script setup lang="ts"></script>

<template>
  <div>
    <p>You need to log in to access the dashboard.</p>
  </div>
</template>
