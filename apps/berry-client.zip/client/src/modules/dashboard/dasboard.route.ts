import { RouteRecordRaw } from 'vue-router';

export const dashboardRoutes: RouteRecordRaw[] = [
  {
    path: '/dashboard',
    name: 'Dashboard',
    component: () => import('./DashboardView.vue'),
    // beforeEnter: (),
    //   to: RouteLocationNormalized,
    //   from: RouteLocationNormalizedLoaded,
    //   next: NavigationGuardNext
    // ): void => {
    //   const { isAuthenticated } = useAuth0();
    //   if (!isAuthenticated.value) next('/');
    //   else next();
    // },
  },
];
