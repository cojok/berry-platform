import { RouteRecordRaw } from 'vue-router';

export const ProfileRoutes: RouteRecordRaw[] = [
  {
    path: '/profile',
    name: 'Profile',
    component: () => import('../views/ProfileView.vue'),
    // beforeEnter: authGuard,
    //   to: RouteLocationNormalized,
    //   from: RouteLocationNormalizedLoaded,
    //   next: NavigationGuardNext
    // ): void => {
    //   const { isAuthenticated } = useAuth0();
    //   if (!isAuthenticated.value) next('/');
    //   else next();
    // },
  },
];
