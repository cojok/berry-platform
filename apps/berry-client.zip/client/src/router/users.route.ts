import { RouteRecordRaw } from 'vue-router';
import UsersView from '../views/UsersView.vue';

export const UsersRoutes: RouteRecordRaw[] = [
  {
    path: '/users',
    name: 'Users',
    component: UsersView,
  },
];
