<template>
  <div class="flex flex-col min-h-screen">
    <!-- Navbar -->
    <div class="bg-gray-800 text-white p-4">
      <Navbar />
    </div>

    <!-- Main Content Area -->
    <div class="flex-1 p-6">
      <div
        class="flex flex-col items-center justify-center min-h-screen text-center"
      >
        <h1 class="text-6xl font-bold text-gray-800">404</h1>
        <p class="text-lg text-gray-600 mt-2">
          Oops! The page you're looking for doesn't exist.
        </p>
        <router-link
          to="/"
          class="mt-6 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
        >
          Go Home
        </router-link>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import Navbar from '../components/layouts/Navbar.vue';
</script>
